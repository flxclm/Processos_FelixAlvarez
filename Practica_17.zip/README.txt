The codes are free for all, you can use it for whatever means you want.

This chat program requires you to have python 2.x installed, python 3.x won't work.

FIRST: CONFIGURE YOUR PROGRAM!
1) install win32gui at http://sourceforge.net/projects/pywin32/files/pywin32/Build%20218/

2) install pygame (http://www.pygame.org/download.shtml)

3) In client.pyw file, go to line 8, replace 'YOUR EXTERNAL IP ADDRESS HERE' with your external 
ip address. You can find it on http://www.whatismyip.com/

4) Login on your default gateway, and enable DMZ, and set DMZ Host IP Address to be the INTERNAL IP ADDRESS of 
YOUR computer, assuming you are the host. (if you don't know how to do this, watch the tutorial on my channel
or send me a message)

NEXT, HOW TO MAKE IT RUN?
On your computer, open the host.pyw file. On your partner's computer, open the client.pyw file.
If it says connected, then you are ready to go!

